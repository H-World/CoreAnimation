//
//  NextViewController.m
//  NavigationBar
//
//  Created by 王寒标 on 2018/8/25.
//  Copyright © 2018年 王寒标. All rights reserved.
//

#import "NextViewController.h"

@interface NextViewController ()

@end

@implementation NextViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    self.extendedLayoutIncludesOpaqueBars = YES;
}

@end

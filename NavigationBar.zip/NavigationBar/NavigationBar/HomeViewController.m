//
//  HomeViewController.m
//  NavigationBar
//
//  Created by 王寒标 on 2018/8/25.
//  Copyright © 2018年 王寒标. All rights reserved.
//

#import "HomeViewController.h"
#import "NextViewController.h"

@interface HomeViewController () <UINavigationControllerDelegate>

@end

@implementation HomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.navigationBar.translucent = NO;
    
    self.navigationController.delegate = self;
    
    UIPanGestureRecognizer *panGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self.navigationController.interactivePopGestureRecognizer.delegate action:NSSelectorFromString(@"handleNavigationTransition:")];
    [self.navigationController.view addGestureRecognizer:panGesture];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    
    if ([viewController isEqual:self]) {
        
        [navigationController setNavigationBarHidden:YES animated:YES];
    } else if ([viewController isKindOfClass:[NextViewController class]]) {
        
        [navigationController setNavigationBarHidden:NO animated:YES];
    } else {
        
        [navigationController setNavigationBarHidden:YES animated:YES];
    }
}

@end

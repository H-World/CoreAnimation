//
//  CoinViewController.m
//  NavigationBar
//
//  Created by 王寒标 on 2018/8/25.
//  Copyright © 2018年 王寒标. All rights reserved.
//

#import "CoinViewController.h"
#import "NextViewController.h"

@interface CoinViewController () <UINavigationControllerDelegate>

@end

@implementation CoinViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationController.delegate = self;
//    [self.navigationController.navigationBar setBackgroundImage:[self getClearColorPNGImage] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.shadowImage = [UIImage new];
}

- (void)navigationController:(UINavigationController *)navigationController willShowViewController:(UIViewController *)viewController animated:(BOOL)animated {
    
    if ([viewController isEqual:self]) {
        
        [navigationController.navigationBar setBackgroundImage:[UIImage new] forBarMetrics:UIBarMetricsDefault];
    } else if ([viewController isKindOfClass:[NextViewController class]]) {
        
        [navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"bg_black"] forBarMetrics:UIBarMetricsDefault];
    } else {
        
        [navigationController.navigationBar setBackgroundImage:[self getClearColorPNGImage] forBarMetrics:UIBarMetricsDefault];
    }
}

- (UIImage *)getClearColorPNGImage {
    //开启一个图片上下文.
    UIGraphicsBeginImageContext(CGSizeMake(200, 200));
    //设置一个透明的颜色
    UIColor * color = [UIColor clearColor];
    //使用上面设置的颜色进行填充.
    [color setFill];
    //从图片上下文中获取图片.
    UIImage * image = UIGraphicsGetImageFromCurrentImageContext();
    //关闭图片上下文,否则会造成内存泄露.
    UIGraphicsEndImageContext();
    return image;
}

@end
